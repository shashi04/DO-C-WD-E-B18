npm run build      # Creates dist/bundle.js
npm run start      # Runs original source code

# OR to run bundled:
node dist/bundle.js
