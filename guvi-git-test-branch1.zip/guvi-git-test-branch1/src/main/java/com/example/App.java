package com.example;

public class App {
    public static void main(String[] args) {
        System.out.println("Hello, Java with Maven!");
    }
}
