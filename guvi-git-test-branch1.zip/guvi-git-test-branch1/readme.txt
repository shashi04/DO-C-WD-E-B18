Build Command:

mvn clean package


Run Command:

java -cp target/guvi-git-test-1.0.0.jar com.example.App
